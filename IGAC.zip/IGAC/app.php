@include('navigation')
@include('footer')
@yield('content')